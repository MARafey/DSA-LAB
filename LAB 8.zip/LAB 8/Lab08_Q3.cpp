#include<iostream>
using namespace std;

template <typename T>
struct Node
{

	T data;
	Node<T>* next;

	Node(T d)
	{
		this->data = d;
		next = nullptr;
	}



};
template <typename T>
class Queue
{

public:
	Node<T>* front;
	Node<T>* rear;

	Queue()
	{
		front = nullptr;
		rear = nullptr;

	}
	string d()
	{
		return data;
	}
	bool isEmpty()
	{

		if (rear == NULL && front == NULL)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	void enqueue(T d)
	{
		Node<T>* temp = new Node<T>(d);
		if (isEmpty())
		{
			front = rear = temp;
		}
		else
		{
			rear->next = temp;
			rear = temp;
		}
	}
	void dequeue()
	{
		if (isEmpty())
		{
			return;
		}
		Node<T>* temp = front;
		front = front->next;

		if (front == nullptr) {
			rear = nullptr;
		}
		delete temp;
	}

	void string_con(string s) {
		int c = 0;
		for (int i = 0; i < s.length(); i++)
		{
			if (s[i] == ' ')
			{
				c++;
			}
		}
		Queue<string>* temp = new Queue<string>[c+1];
		int position = 0;
		string d = "";
		for (int i = 0; i < s.length()+1; i++)
		{
			if (s[i] != ' ')
			{
				d += s[i];
			}
			if (s[i] == ' ')
			{
				temp[position++].enqueue(d);
				d = "";
			}
			if (s[i] == '\0')
			{
				temp[position++].enqueue(d);
				d = "";
			}
		}
		for (int i = 0; i < position; i++)
		{
			temp[i].print();
		}
	}
	void print()
	{
		cout << rear->data << endl;
	}
};
//int main()
//{
//	Queue<string> obj;
//	obj.string_con("Data Structure and Algorithms\0");
//
//}
//
//
