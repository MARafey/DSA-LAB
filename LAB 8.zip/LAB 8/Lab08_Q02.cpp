#include<iostream>
using namespace std;

struct Node
{
	int data;
	Node* next;

	Node(int d = 0)
	{
		data = d;
		next = NULL;

	}
};


class Queue
{

public:
	Node* front;
	Node* rear;

	Queue()
	{
		front = rear = nullptr;

	}

	void enqueue(int d)
	{
		Node* newnode = new Node(d);

		if (rear == nullptr)
		{
			front = rear = newnode;
		}
		else {
			rear->next = newnode;
			rear = newnode;
		}
	}


	void dequeue()
	{
		if (isEmpty())
		{
			return;
		}

		Node* temp = front;
		front = front->next;
		if (front == NULL)
		{
			rear = NULL;
		}
		delete temp;
	}

	bool isEmpty() {

		if (front == nullptr && rear == nullptr) {
			return true;
		}

		else
		{
			return false;
		}

	}

	int Front()
	{
		if (front == nullptr)
		{
			return 0;

		}

		else {
			return front->data;
		}
	}

	void print()
	{

		while (rear != NULL)
		{
			cout << front->data << endl;
			cout << rear->data << endl;
			rear = rear->next;
			front = front->next;
		}



	}

	void RoundRobbin(Queue q, int time)
	{
		while (q.front!= NULL)
		{
			int diff = q.front->data - time;
			cout << "exection time = " << q.front->data << endl;
			cout << "time left = " << diff << endl;
			if (diff <= 0)
			{
				cout << "RESCEDULED\n\n\n" << endl;
			}
			else
			{
				cout << "Task done\n\n";
				q.enqueue(diff);
			}
			q.dequeue();
		}
	}


};

int main()
{
	Queue obj;
	obj.enqueue(10);
	obj.enqueue(20);
	obj.enqueue(30);
obj.RoundRobbin(obj, 5);

}