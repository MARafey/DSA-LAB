#include<iostream>
using namespace std;
template <typename T>
struct Node
{

	T data;
	Node<T>* next;

	Node(T d)
	{
		this->data = d;
		next = nullptr;
	}



};
template <typename T>
class Queue
{

public:
	Node<T>* front;
	Node<T>* rear;

	Queue()
	{
		front = nullptr;
		rear = nullptr;

	}
	bool isEmpty()
	{

		if (rear == NULL && front == NULL)
		{
			cout << "Is Empty" << endl;
			return true;
		}
		else
		{
			return false;
		}
	}
	void enqueue(T d)
	{
		Node<T>* temp = new Node<T>(d);
		if (isEmpty())
		{
			front = rear = temp;
		}
		else
		{
			rear->next = temp;
			rear = temp;
		}
	}
	void dequeue()
	{
		if (isEmpty())
		{
			return;
		}
		else if (front != NULL)
		{
			Node<T>* temp = front;
			front = front->next;
			delete temp;

		}
	}
	int Front()
	{
		return front->data;
	}
	
	void print()
	{

		while (rear != NULL)
		{
			cout << front->data << endl;
			cout << rear->data << endl;
			rear = rear->next;
			front = front->next;
		}

	}

};

//
//
//int main()
//{
//	Queue<int> Q1;
//	Q1.enqueue(5);
//	Q1.enqueue(10);
//	Q1.enqueue(15);
//	Q1.enqueue(20);
//	//Q1.dequeue();
//	Q1.print();
//}
//
