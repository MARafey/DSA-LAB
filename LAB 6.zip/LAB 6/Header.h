#include<iostream>
#include<conio.h>

using namespace std;
template <class T>
class Node
{
public:
	T data;
	Node* next;

	Node()
	{
		data = 0;
		next = NULL;
	}

	Node(T d, Node* n)
	{
		data = d;
		next = n;
	}

	Node(T d)
	{
		data = d;
		next = NULL;

	}
	

	void setData(T d)
	{
		data = d;
	}

	void setNext(Node* n)
	{
		next = n;
	}

	T getData()
	{
		return data;
	}

	Node* getNext()
	{
		return next;
	}

};

template <class T>
class SLinkedList {

public:

	Node<T>* head;


	SLinkedList()
	{
		head = NULL;
	}
	
	void insert(T d)
	{
		Node<T>* temp = new Node<T>(d);
		Node<T>* n = head;
		if (head == NULL)
		{
			head = temp;
			return;
		}
		else
		{
			while (n->next != NULL)
			{
				n = n->next;
			}
			n->next = temp;
		}
	}
	void insertAtHead(T d)
	{
		Node<T>* p = new Node<T>(d);
		p->next = head;
		head = p;
	}
	void InsertAtIndex(T d, int index)
	{
		Node<T>* temp = new Node<T>(d);
		Node<T>* temp2;
		temp2 = head;
		for (int i = 0; i < index-1; i++)
		{
			temp2 = temp2->next;
		}
		Node<T>* temp3;
		temp3 = temp2->next;
		temp2->next = temp;
		temp->next = temp3;
	}
	int search(T d)
	{
		Node<T>* temp2;
		temp2 = head;
		for (int i = 0; i < d; i++)
		{
			temp2 = temp2->next;
		}return temp2->data;
	}
	void remove(int t)
	{
		Node<T>* temp2;
		temp2 = head;
		for (int i = 0; i < t; i++)
		{
			temp2 = temp2->next;
		}
		temp2->next = temp2->next->next;
	}
	void update(int t,T d)
	{
		Node<T>* temp2;
		temp2 = head;
		for (int i = 0; i < t; i++)
		{
			temp2 = temp2->next;
		}
		temp2->data = d;
	}
	bool isEmpty()
	{
		if (head == NULL)
		{
			return true;
		}
		return false;
	}
	void print()
	{
		Node<T>* temp2;
		temp2 = head;
		for (int i = 0;i<4; i++)
		{
			cout << temp2->data << "-->";
			temp2 = temp2->next;
		}
	}

	void mergeLists(SLinkedList l2)
	{
		SLinkedList<int> obj;
		for (int x = 0; x < 4; x++) {
			obj.insert(this->search(x));
			obj.insert(l2.search(x));
		}
		head = obj.head;
	}
};