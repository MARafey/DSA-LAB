#include<iostream>
using namespace std;

template <typename T>
class node
{
public:
	T* data;
	node<T>* next;

	node(T* d)
	{
		this->data = d;
		next = nullptr;
	}



};

template <typename T>
class queue
{
	node<T>* front;
	node<T>* back;
public:
	queue()
	{
		front = back = NULL;
	}
	void push(T* x)
	{
		node<T>* n = new node<T>(x);
		if (front == NULL)
		{
			back = n;
			front = n;
			return;
		}
		back->next = n;
		back = n;
	}
	void pop()
	{
		if (front == NULL)
		{
			return;
		}
		node<T>* temp = front;
		front = front->next;
		delete temp;
	}
	T* peek()
	{
		return front->data;
	}
	bool IsEmpty()
	{
		if (front == NULL)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

};

template <typename T>
class Stack
{
	node<T>* top;
public:
	Stack()
	{
		top = NULL;
	}
	void push(T x)
	{
		node<T>* n = new node<T>(x);
		n->data = x;
		n->next = top;
		top = n;
	}
	void pop()
	{
		if (top == NULL)
		{
			return;
		}
		node<T>* temp = top;
		top = top->next;
		delete temp;
	}
	T peek()
	{
		if (!IsEmpty())
		{
			return top->data;
		}
	}
	bool IsEmpty()
	{
		if (top == NULL)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
};

template <typename T>
struct Node
{
	T data;
	Node* left;
	Node* right;

	Node(T val)
	{
		this->data = val;
		this->left = this->right = NULL;
	}
	int height(Node* n)
	{
		if (n == NULL)
		{
			return 0;
		}
		int lheight = height(n->left);
		int rheight = height(n->right);

		if (lheight > rheight)
		{
			return (lheight + 1);
		}
		else
		{
			return (rheight + 1);
		}
	}
	void LEVELorder(Node* root)
	{
		int h = height(root);
		int i;
		for (i = 1; i <= h; i++)
			printCurrentLevel(root, i);
	}

	void printCurrentLevel(Node* root, int level)
	{
		if (root == NULL)
			return;
		if (level == 1)
			cout << root->data << " ";
		else if (level > 1) {
			printCurrentLevel(root->left, level - 1);
			printCurrentLevel(root->right, level - 1);
		}
	}
};

template <typename T>
Node<T>* successor(Node<T>* root)
{
	Node<T>* temp = root;
	while (temp->left != NULL && temp)
	{
		temp = temp->left;
	}
	return temp;
}

template <typename T>
Node<T>* insert(T val, Node<T>* root)
{
	if (root == NULL)
	{

		return new Node<T>(val);
	}
	if (val < root->data)
	{
		root->left = insert(val, root->left);
	}
	else
	{
		root->right = insert(val, root->right);
	}
	return root;
}

template <typename T>
Node<T>* retrive(T val, Node<T>* root)
{
	if (root == NULL)
	{
		return NULL;
	}
	if (root->data == val)
	{
		return root;
	}
	if (val < root->data)
	{
		return retrive(val, root->left);
	}
	else
	{
		return retrive(val, root->right);
	}

}

template <typename T>
Node<T>* getMin(Node<T>* root)
{
	if (root->left == NULL)
	{
		return root;
	}

	return getMin(root->left);

}

template <typename T>
Node<T>* getMax(Node<T>* root)
{
	if (root->right == NULL)
	{
		return root;
	}

	return getMin(root->right);

}

template <typename T>
Node<T>* delete_node(T val, Node<T>* root)
{
	if (val < root->data)
	{
		root->left = delete_node(val, root->left);
	}
	else if (val > root->data)
	{
		root->right = delete_node(val, root->right);
	}
	else
	{
		if (root->left == NULL)
		{
			Node<T>* temp = root->right;
			delete root;
			return temp;
		}
		else if (root->right == NULL)
		{
			Node<T>* temp = root->left;
			delete root;
			return temp;
		}
		else
		{
			Node<T>* temp = successor(root->right);
			root->data = temp->data;
			root->right = delete_node(temp->data, root->right);
		}
	}
	return root;
}

template <typename T>
void Inorder_display(Node<T>* root)
{
	if (root == NULL)
	{
		return;
	}
	Inorder_display(root->left);
	cout << root->data << "--->";
	Inorder_display(root->right);
}

template <typename T>
void posr_display(Node<T>* root)
{
	if (root == NULL)
	{
		return;
	}
	posr_display(root->left);
	cout << root->data << " ";
	posr_display(root->right);
}

template <typename T>
void mirror(Node<T>*& root)
{
	queue<Node<T>> q;

	q.push(root->left);
	q.push(root->right);

	root->left = root->right = NULL;

	root->right = q.peek();
	q.pop();
	root->left = q.peek();
	q.pop();

}

int priority(char op) {
	if ((op == '+') || (op == '-'))
		return 1;
	if ((op == '/') || (op == '*'))
		return 2;
}