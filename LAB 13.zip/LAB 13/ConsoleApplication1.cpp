#include<iostream>
#include"Header.h"
using namespace std;

int main()
{
	Node<int>* tree = NULL;
	tree = insert(100, tree);
	insert(70, tree);
	insert(50, tree);
	insert(80, tree);

	insert(150, tree);
	insert(170, tree);
	insert(180, tree);

	Inorder_display(tree);
	cout << endl;
	mirror(tree);
	cout << endl;
	Inorder_display(tree);
	cout << endl;

	string a = "a+b-c";
	Node<char>* root = NULL;
	root = insert(a[a.length()-1], root);
	for (int i = a.length()-2; i > -1; i--)
	{
		insert(a[i], root);
	}
	posr_display(root);
}
