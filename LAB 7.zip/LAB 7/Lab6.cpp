// Lab6.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <iostream>
using namespace std;
template <typename T1, typename T2>
class node
{
public:
	T1 EmpID;
	T1 CNIC;
	T1 JoiningDate;
	T2 Salary;
	T2 Bonus;
	node<T1, T2>* next;
	node<T1, T2>* prev;
	node()
	{
		next = NULL;
		prev = NULL;
	}
	node(T1 id, T1 CNIC, T1 JoiningDate, T2 salary, T2 bonus)
	{
		this->EmpID = id;
		this->CNIC = CNIC;
		this->JoiningDate = JoiningDate;
		this->Salary = salary;
		this->Bonus = bonus;
	}
};

template <class T1, class T2>
class linkList
{
public:
	node<T1, T2>* head;
	node<T1, T2>* tail;

	linkList()
	{
		head = tail = NULL;
	}

	void insert(T1 id, T1 CNIC, T1 JoiningDate, T2 salary, T2 bonus)
	{
		node<T1, T2>* temp = new node<T1,T2>(id,CNIC,JoiningDate,salary,bonus);

		if (isEmpty()) {
			head = tail = temp;
			head->prev = tail;
			tail->next = head;
			cout << "1.Created" << endl;
		}
		else
		{
			
			tail->next = temp;
			temp->next = head;
			head->prev = temp;
			tail->next = head;
			cout << "Created" << endl;
		}
		
				
	}
	void search(T1 id)
	{
		node<T1, T2>* temp = new node<T1, T2>();
		temp = head->next;
		while (temp != head)
		{
			if (id == temp->EmpID)
			{
				cout << "Employee Found " << endl;
				cout << "Employee ID: " << temp->EmpID << endl;
				cout << "CNIC: " << temp->CNIC << endl;
				cout << "Joining Date: " << temp->JoiningDate << endl;
				cout << "Salary: " << temp->Salary << endl;
				cout << "Bonus: " << temp->Bonus;
			}

			temp = temp->next;
		}
		

	}
	void UpdateSalary(T1 id, T2 newSalary)
	{
		node<T1, T2>* temp = new node<T1, T2>();
		temp = head->next;
		while (temp != head)
		{
			if (id == temp->EmpID)
			{
				cout << "Employee Found " << endl;
				temp->Salary = newSalary;
				cout << "New salary = " << temp->Salary << endl;
			}

			temp = temp->next;
		}
	}
	T2 MaxSalary()
	{
		node<T1, T2>* temp = new node<T1, T2>();
		temp = head->next;
		T2 max_salary = temp->Salary;
		while (temp != head)
		{
			if (temp->Salary > max_salary)
			{
				max_salary = temp->Salary;
			}
			temp = temp->next;
		}
		return max_salary;
	}
	bool isEmpty()
	{
		if (head == NULL && tail == NULL)
		{
			return true;
		}
		return false;
	}
	void print()
	{
		node<T1, T2>* temp = new node<T1, T2>();
		temp = head->next;
		while (temp != head)	
		{
			cout << "--------------------------------------------------------------\n";
			cout << "Employee ID: " << temp->EmpID << endl;
			cout << "CNIC: " << temp->CNIC << endl;
			cout << "Joining Date: " << temp->JoiningDate << endl;
			cout << "Salary: " << temp->Salary << endl;
			cout << "Bonus: " << temp->Bonus;
			cout << "--------------------------------------------------------------\n";

			temp = temp->next;
		}
	}

};
int main()
{
	linkList<string, int> n;
	cout << n.isEmpty() << endl;
	n.insert("001", "6110154368375", "9/10/2002", 1000, 0);
	n.insert("002", "6110154358375", "9/11/2000", 1030, 100);
	n.insert("003", "6110154388375", "9/1/2001", 9000, 90);
	cout << n.MaxSalary() << endl;
	n.print();
}

