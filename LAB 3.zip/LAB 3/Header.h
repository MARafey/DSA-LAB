#pragma once
#include<iostream>
#include<string>
#include<fstream>
using namespace std;
int arraySum(int arr[5][5], int row, int column)
{
	int sum = 0;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < column; j++)
		{
			sum += arr[i][j];
		}
	}
	return sum;
}

int* rowSum(int arr[][4], int row, int column)
{
	int* sum = new int[row] {0};
	int k = 0;
	for (int i = 0; i < row; i++)
	{
		for (size_t j = 0; j < column; j++)
		{
			sum[k] += arr[i][j];
		}
		k++;
	}
	return sum;
}


int* colSum(int arr[][4], int row, int column)
{
	int* sum = new int[row] {0};
	int k = 0;
	for (int i = 0; i < column; i++)
	{
		for (size_t j = 0; j < row; j++)
		{
			sum[k] += arr[j][i];
		}
		k++;
	}
	return sum;
}

int** transposeMatrix(int arr[][2], int row, int column)
{
	int** trans = new int* [column];
	for (int i = 0; i < column; i++)
	{
		trans[i] = new int[row];
	}
	for (int i = 0; i < row; i++)
	{
		for (size_t j = 0; j < column; j++)
		{
			trans[i][j] = arr[j][i];
		}

	}
	return trans;
}

int** matrixSum(int arr[][3], int arr1[][3], int row, int column)
{
	int** sum = new int* [column];
	for (int i = 0; i < column; i++)
	{
		sum[i] = new int[row];
	}
	for (int i = 0; i < row; i++)
	{
		for (size_t j = 0; j < column; j++)
		{
			sum[i][j] = arr[i][j] + arr1[i][j];
		}
	}
	return sum;
}

int multiplyMatrix(int arr[][4], int arr1[][4], int row, int column, int row2, int column2)
{
	int** sum = new int* [column] {0};
	for (int i = 0; i < column; i++)
	{
		sum[i] = new int[row] {0};
	}
	for (int i = 0; i < 4; ++i) {
		for (int j = 0; j < 4; ++j) {
			for (int k = 0; k < 4; ++k)
			{
				sum[i][j] += arr[i][k] * arr1[k][j];
			}
		}
	}
	int sum1 = 0;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < column; j++)
		{
			sum1 += sum[i][j];
		}
	}
	return sum1;
}

int leftDiagonalSum(int arr[][4], int row, int column)
{
	int sum = 0;
	int i = 0;
	int j = 0;
	while (i < row)
	{
		sum += arr[i++][j++];
	}
	return sum;
}
int rightDiagonalSum(int arr[][4], int row, int column)
{
	int sum = 0;
	int i = row - 1;
	int j = 0;
	while (i >= 0)
	{
		sum += arr[i--][j++];
	}
	return sum;
}

int* displayMiddleRow(int arr[][5], int row)
{
	int* ans = new int[row];
	for (int i = 0; i < row; i++)
	{
		ans[i] = arr[2][i];

	}
	return ans;
}

int* displayMiddleCol(int arr[][5], int row)
{
	int* ans = new int[row];
	for (int i = 0; i < row; i++)
	{
		ans[i] = arr[i][2];

	}
	return ans;
}

int* toIntArray(std::string str)
{
	int* arr = new int[str.length()];
	for (int i = 0; i < str.length(); i++)
	{
		arr[i] = str[i] - '0';
	}
	return arr;
}

int* addTwoArray(std::string str, std::string ptr)
{
	int* st = toIntArray(str);
	int* pt = toIntArray(ptr);
	int size = (str.length() > ptr.length()) ? str.length() : ptr.length();
	int* ans = new int[size];
	for (int i = 0; i < size; i++)
	{
		ans[i] = 0;
	}
	for (int i = size - 1; i >= 0; i--)
	{
		ans[i] = st[i] + pt[i];
		if (ans[i] > 10)
		{
			ans[i] = ans[i] % 10;
			ans[i - 1] += 1;
		}
	}
	return ans;
}

int* subTwoArray(std::string str, std::string ptr)
{
	int* st = toIntArray(str);
	int* pt = toIntArray(ptr);
	int size = (str.length() > ptr.length()) ? str.length() : ptr.length();
	int* ans = new int[size];
	for (int i = 0; i < size; i++)
	{
		ans[i] = 0;
	}
	for (int i = size - 1; i >= 0; i--)
	{
		if (st[i] - pt[i] >= 0) {
			ans[i] = st[i] - pt[i];
		}
		else
		{
			st[i - 1] -= 1;
			st[i] += 10;
			ans[i] = st[i] - pt[i];
		}
	}

	return ans;
}

int* readFromFile()
{
	int arr[5][5] = { {1,1,1,1,1},{1,1,1,1,1},{1,1,1,1,1}, {1,1,1,1,1}, {1,1,1,1,1}};

	ofstream myfile("data.txt");
	if (myfile.is_open())
	{
		for (int i = 0; i < 5; i++)
		{
			for (int j = 0; j < 5; j++)
			{
				myfile << arr[i][j];
			}
			myfile << "\0";
			myfile << "\n";
		}
		myfile.close();
	}
	int* ans = new int[5];
	string text;
	ifstream file("data.txt"); int i = 0;
	int sum = 0;
	int k = 0;
	if (file.is_open())
	{
		while (getline(file, text)) {
			while (text[i]!='\0')
			{
				sum += text[i++] - 48;
			}
			ans[k++] = sum;
			sum = 0;
			i = 0;

		}
		myfile.close();
	}
	return ans;
}