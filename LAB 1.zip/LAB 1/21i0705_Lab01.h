#pragma once
template <typename T> T smaller(T first, T second)
{
	if (first < second)
	{
		return first;
	}
	else
	{
		return second;
	}
}

template <typename T> T smaller(T first, T second, T third)
{
	if (first < second && first < third)
	{
		return first;
	}
	else if (second < first && second < third)
	{
		return second;
	}
	else
		return third;
}
template <typename T> T* sameElement(T* arr1, T* arr2, T a, T b)
{
	
	T* arr = new T[a + b];
	int position = 0;
	for (int i = 0; i < a; i++)
	{
		for (int j = 0; j < b; j++)
		{
			if (arr1[i] == arr2[j])
			{
				arr[position++] = arr1[i];
			}
		}
	}
	return arr;
}

template <typename T> T* concatenateArrays(T* arr1, T* arr2, T a, T b)
{
	T* result = new T[a + b];
	for (int i = 0; i < a; i++)
	{
		result[i] = arr1[i];
	}
	bool flag = 1;
	int position = 0;
	for (int i = 0; i < b; i++)
	{
		for (int j = 0; j < a; j++)
		{
			if (result[j] == arr2[i])
			{
				flag = 0;
				break;
			}
		}
		if (flag)
		{
			result[a + position++] = arr2[i];
		}
		flag = 1;
	}
	return result;
}


template <class T>
class container {
private:
	T* values;
	int capacity;
	int counter;

public:
	container(int cap = 0, T num = 0, int count = 0)
	{
		capacity = cap;
		counter = 0;
		values = new T[capacity];
	}
	bool insert(T a)
	{
		if (!isFull())
		{
			values[counter++] = a;
			return true;
		}
		else
			return false;
	}
	bool search(T a)
	{
		for (int i = 0; i < capacity; i++)
		{
			if (values[i] == a)
			{
				return true;
			}
		}
		
		return false;
	}
	bool remove(T a)
	{
		for (int i = 0; i < capacity; i++)
		{
			if (values[i] == a)
			{
				for (int j = i; j < capacity; j++)
				{
					values[j] = values[j + 1];
				}
				counter--;
				return true;
			}
		}
		
		return false;
	}
	bool isFull()
	{
		if (capacity == counter)
		{
			return true;
		}
		else
			return false;
	}
};