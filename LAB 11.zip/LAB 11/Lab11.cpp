#include <iostream>
using namespace std;

class NODE
{
public:
	int data;
	NODE* Left;
	NODE* Right;

	NODE(int d)
	{
		this->data = d;
		Left = Right = nullptr;
	}
};

class BSTree
{
public:
	NODE* root;
	BSTree(int d = 0)
	{
		NODE* temp = new NODE(d);
		root = temp;
	}
	bool search(int d, NODE* root)
	{
		if (root == NULL)
		{
			return false;
		}
		if (root->data = d)
		{
			return true;
		}
		if (search(d, root->Left)) return 1;
		if (search(d, root->Right)) return 1;
		return 0;

	}
	void insert(int n)
	{
		NODE* newNode;
		NODE* nodePtr;

		newNode = new NODE(n);

		if (!root)
		{
			root = newNode;
		}
		else
		{
			nodePtr = root;
			while (nodePtr != 0)
			{
				if (n < nodePtr->data)
				{
					if (nodePtr->Left)
					{
						nodePtr = nodePtr->Left;
					}
					else
					{
						nodePtr->Left = newNode;
						break;
					}
				}

				else if (n > nodePtr->data)
				{
					if (nodePtr->Right)
					{
						nodePtr = nodePtr->Right;
					}
					else
					{
						nodePtr->Right = newNode;
						break;
					}
				}
				else {
					cout << "Dup found\n";
					return;
				}
			}

		}
	}
	void PreOrderTraversal(NODE* r)
	{
		if (r == NULL)
		{
			return;
		}
		cout << r->data << "-->";
		PreOrderTraversal(r->Left);
		PreOrderTraversal(r->Right);

	}
	void PostOrderTraversal(NODE* r)
	{
		if (r == NULL)
		{
			return;
		}

		PostOrderTraversal(r->Right);
		PostOrderTraversal(r->Left);
		cout << r->data << "-->";
	}
	void InOrderTraversal(NODE* r)
	{
		if (r == NULL)
		{
			return;
		}

		InOrderTraversal(r->Left);
		cout << r->data << "-->";
		InOrderTraversal(r->Right);
	}
	int height(NODE* n)
	{
		if (n == NULL)
		{
			return 0;
		}
		int lheight = height(n->Left);
		int rheight = height(n->Right);

		if (lheight > rheight)
		{
			return (lheight+1);
		}
		else
		{
			return (rheight+1);
		}
	}
	void LEVELorder(NODE* root)
	{
		int h = height(root);
		int i;
		for (i = 1; i <= h; i++)
			printCurrentLevel(root, i);
	}

	void printCurrentLevel(NODE* root, int level)
	{
		if (root == NULL)
			return;
		if (level == 1)
			cout << root->data << " ";
		else if (level > 1) {
			printCurrentLevel(root->Left, level - 1);
			printCurrentLevel(root->Right, level - 1);
		}
	}
};
int main()
{
	BSTree r(5);

	r.insert(3);
	r.insert(1);
	r.insert(9);
	r.insert(6);

	r.InOrderTraversal(r.root);
	cout << endl;
	r.PreOrderTraversal(r.root);
	cout << endl;
	r.PostOrderTraversal(r.root);
	cout << endl;
	cout << "the number " << 9 << ": " << r.search(9, r.root);
	cout << endl;
	r.LEVELorder(r.root);
}