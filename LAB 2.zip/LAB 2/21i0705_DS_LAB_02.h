#pragma once
#include<math.h>

bool checking_palindrom(std::string str, int i, int j)
{
	if (i > j)
	{
		return true;
	}
	if (str[i] != str[j])
	{
		return false;
	}
	checking_palindrom(str, i+1, j-1);
}

template <typename T>
T add(T a, T b)
{
	return a + b;
}
template <typename T>
T* add(T* a, T* b)
{
	T* arr = new T[5];
	for (int i = 0; i < 5; i++)
	{
		arr[i] = a[i] + b[i];
	}

	return arr;
}
template <typename T>
T sub(T a, T b)
{
	return a - b;
}
template <typename T>
T Div(T a, T b)
{
	return T(a) / b;
}
template <typename T>
bool prime(T n)
{
	bool flag = 1;
	if (n == 0 || n == 1)
		flag = 1;

	for (int i = 2; i <= n / 2; ++i) {

		if (n % i == 0) {
			flag = 0;
			break;
		}
	}
	return flag;
}
template <typename T>
T Fact(T a)
{
	if (a == 1)
		return 1;
	return a * Fact(a - 1);
}
template <typename T>
T SQRT(T a)
{
	return sqrt(a);
}
int SplitToSets(int arr[], int size)
{
	int temp;
	for (int i = 0; i < size; ++i) {
		for (int j = i + 1; j < size; ++j) {
			if (arr[i] > arr[j]) {
				temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}
	}
	int size1 = size / 2 + size % 2;
	int size2 = size / 2;
	int* arr1 = new int[size1];
	int* arr2 = new int[size2];
	bool flag = 1;
	if (size1 % 2 == 0)
	{
		flag = 0;
	}
	int a = 0;
	if (flag) {
		for (int i = size1 - 1; i < size; i++)
		{
			arr1[a++] = arr[i];
		}
	}
	else
	{
		for (int i = size1; i < size; i++)
		{
			arr1[a++] = arr[i];
		}
	}

	a = 0;
	for (int i = 0; i < size2; i++)
	{
		arr2[a++] = arr[i];
	}
	int sum1 = 0, sum2 = 0;
	for (int i = 0; i < size1; i++)
	{
		sum1 = sum1 + arr1[i];
		if (i < size2)
		{
			sum2 = sum2 + arr2[i];
		}
	}
	return sum1 - sum2;
}

bool superString(std::string str)
{
	char alpha[] = "ZYXWVUTSRQPONMLKJIHGFEDCBA";
	int count = 0;
	for (int i = 0; i < str.length(); i++)
	{
		count = 0;
		for (int j = 0; j < str.length(); j++)
		{
			if (str[i] == str[j] && i != j)
			{
				count++;
			}
		}
		for (int k = 0; k < 26; k++)
		{
			if (alpha[k] == str[i])
			{
				if (count != k)
				{
					return false;
				}
			}
		}
	}
	return true;
}

int subPalindrome(std::string str)
{
	//int count = str.length();
	int count = 0;
	std::string a = "";
	bool flag = 1;
	for (int i = 0; i < str.length(); i++)
	{
		for (int j = 0; j < a.length(); j++)
		{
			if (str[i] == a[j])
			{
				flag = 0;
				break;
			}
		}
		if (flag)
		{
			a += str[i];
		}
		flag = 1;
	}
	count = a.length();
	for (int i = 0; i < str.length(); i++)
	{
		for (int j = i+1; j < str.length(); j++)
		{
			if (checking_palindrom(str, i, j))
			{
				count++;
			}
		}
	}
	

	return count;
}

int* toIntArray(std::string str)
{
	int* arr = new int[str.length()];
	for (int i = 0; i < str.length(); i++)
	{
		arr[i] = str[i] - '0';
	}
	return arr;
}

int* addTwoArray(std::string str, std::string ptr)
{
	int* st = toIntArray(str);
	int* pt = toIntArray(ptr);
	int size = (str.length() > ptr.length()) ? str.length() : ptr.length();
	int* ans = new int[size];
	for (int i = 0; i < size; i++)
	{
		ans[i] = 0;
	}
	for (int i = size-1; i >=0; i--)
	{
		ans[i] = st[i] + pt[i];
		if (ans[i] > 10)
		{
			ans[i] = ans[i] % 10;
			ans[i - 1] += 1;
		}
	}
	return ans;
}

int* subTwoArray(std::string str, std::string ptr)
{
	int* st = toIntArray(str);
	int* pt = toIntArray(ptr);
	int size = (str.length() > ptr.length()) ? str.length() : ptr.length();
	int* ans = new int[size];
	for (int i = 0; i < size; i++)
	{
		ans[i] = 0;
	}
	for (int i = size-1; i >= 0; i--)
	{
		if (st[i] - pt[i] >= 0) {
			ans[i] = st[i] - pt[i];
		}
		else
		{
			st[i - 1] -= 1;
			st[i] += 10;
			ans[i] = st[i] - pt[i];
		}
	}

	return ans;
}