#include<iostream>
#include<string>
using namespace std;
void allocate(int**& amp, int nrows, int ncols)
{
	amp = new int*[nrows];
	for (int i = 0; i < nrows; i++)
	{
		amp[i] = new int[ncols];
	}
	for (int i = 0; i < nrows; i++)
	{
		for (int j = 0; j < ncols; j++)
		{
			amp[i][j] = rand() % 100;
		}
	}
}
void deallocate(int** p, int nrows, int ncols)
{
	for (int i = 0; i < nrows; i++)
	{
		delete[] p[i];
	}
	delete[] p;
}
int* max(int**& amp, int nrows, int ncols)
{
	int* sum = new int[nrows]{0};
	int k = 0;
	int temp;
	while (k<nrows)
	{
		for (int i = 0; i < ncols; i++)
		{
			for (int j = 0; j < ncols; j++)
			{
				if (amp[k][i] < amp[k][j]) {
					temp = amp[k][i];
					amp[k][i] = amp[k][j];
					amp[k][j] = temp;
				}
			}
		}
		k++;
	}
	for (int i = 0; i < nrows; i++)
	{
		sum[i] = amp[i][ncols - 1];
	}
	deallocate(amp, nrows, ncols);
	return sum;
}
int** sum(int nrows, int ncols)
{
	int** matrix;
	int** matrix2;
	allocate(matrix, nrows, ncols);
	allocate(matrix2, nrows, ncols);
	int** summing;
	allocate(summing, nrows, ncols);
	for (int i = 0; i < nrows; i++)
	{
		for (int j = 0; j < ncols; j++)
		{
			summing[i][j] = matrix[i][j] + matrix2[i][j];
		}
	}
	deallocate(matrix, nrows, ncols);
	deallocate(matrix2, nrows, ncols);
	for (int j = 0; j < nrows; j++)
	{
		for (int k = 0; k < ncols; k++)
		{
			cout << summing[j][k] << " ";
		}
		cout << endl;
	}
	return summing;
}
void allocateThreeD(int***& amp, int npages, int rows, int cols)
{
	amp = new int** [npages];
	for (int i = 0; i < npages; i++)
	{
		amp[i] = new int*[rows];
		for (int j = 0; j < cols; j++)
		{
			amp[i][j] = new int[cols]{rand()%100};
		}
	}
	for (int i = 0; i < npages; i++)
	{
		cout << "Page " << i + 1 << endl;
		for (int j = 0; j < rows; j++)
		{
			for (int k = 0; k < cols; k++)
			{
				cout << amp[i][j][k] << " ";
			}
			cout << endl;
		}
	}
}
void deAllocateThreeD(int*** p, int npages, int rows, int cols) {
	for (int i = 0; i < npages; i++) {
		for (int j = 0; j < rows; j++) {
			delete[] p[i][j];
		}
		delete[] p[i];
	}
	delete[] p;
}

int main()
{
	int** amp=sum(5,5);
	int*** ptr;
	allocateThreeD(ptr, 5, 5, 5);
}
