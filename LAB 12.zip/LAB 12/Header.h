#include<iostream>
using namespace std;

struct Node
{
	int data;
	Node* left;
	Node* right;

	Node(int val)
	{
		this->data = val;
		this->left = this->right = NULL;
	}
};

Node* successor(Node* root)
{
	Node* temp = root;
	while (temp->left != NULL && temp)
	{
		temp = temp->left;
	}
	return temp;
}

Node* insert(int val, Node* root)
{
	if (root == NULL)
	{

		return new Node(val);
	}
	if (val < root->data)
	{
		root->left = insert(val, root->left);
	}
	else
	{
		root->right = insert(val, root->right);
	}
	return root;
}

Node* retrive(int val, Node* root)
{
	if (root == NULL)
	{
		return NULL;
	}
	if (root->data == val)
	{
		return root;
	}
	if (val < root->data)
	{
		return retrive(val, root->left);
	}
	else
	{
		return retrive(val, root->right);
	}

}

Node* getMin(Node* root)
{
	if (root->left == NULL)
	{
		return root;
	}

	return getMin(root->left);

}

Node* getMax(Node* root)
{
	if (root->right == NULL)
	{
		return root;
	}

	return getMin(root->right);

}

Node* delete_node(int val, Node* root)
{
	if (val < root->data)
	{
		root->left = delete_node(val, root->left);
	}
	else if (val > root->data)
	{
		root->right = delete_node(val, root->right);
	}
	else
	{
		if (root->left == NULL)
		{
			Node* temp = root->right;
			delete root;
			return temp;
		}
		else if (root->right == NULL)
		{
			Node* temp = root->left;
			delete root;
			return temp;
		}
		else 
		{
			Node* temp = successor(root->right);
			root->data = temp->data;
			root->right = delete_node(temp->data, root->right);
		}
	}
		return root;
}

void Inorder_display(Node* root)
{
	if (root == NULL)
	{
		return;
	}
	Inorder_display(root->left);
	cout << root->data << "--->";
	Inorder_display(root->right);
}