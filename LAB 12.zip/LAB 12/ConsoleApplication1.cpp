#include<iostream>
#include"Header.h"
using namespace std;

int main()
{
	Node* root = NULL;
	root = insert(5, root);
	insert(1, root);
	insert(3, root);
	insert(4, root);
	insert(2, root);
	insert(7, root);

	cout << "*-*-*-*-*-*-*-*-*-*Before*-*-*-*-*-*-*-*-*-*" << endl;
	Inorder_display(root);

	delete_node(7, root);

	cout << "\n*-*-*-*-*-*-*-*-*-*After*-*-*-*-*-*-*-*-*-*" << endl;
	Inorder_display(root);

	Node* temp = getMin(root);
	cout << "\n\nMin in tree  : " << temp->data;
	temp = getMax(root);
	cout << "\n\nMax in tree  : " << temp->data;
}


