#include <iostream>
using namespace std;

template <typename T>
class Graph
{
public:
	Graph(T a)
	{
		vetixes = a;
		vetrix_Graph = new bool* [vetixes];
		for (int i = 0; i < vetixes; i++)
		{
			vetrix_Graph[i] = new bool[vetixes] {false};
		}
	}
	void addEdge(int i, int j) //marks the edge true in matrix
	{
		vetrix_Graph[i][j] = true;
		vetrix_Graph[j][i] = true;
	}
	void removeEdge(int i, int j) //removes the edge at provided position
	{
		vetrix_Graph[i][j] = false;
		vetrix_Graph[j][i] = false;
	}
	bool isEdge(int i, int j)
	{
		return vetrix_Graph[i][j];
	}
	void print()
	{
		for (int i = 0; i < vetixes; i++)
		{
			cout << "The node " << i << " is linked to ----> ";
			for (int j = 0; j < vetixes; j++)
			{
				if (vetrix_Graph[i][j])
				{
					cout << j << " ";
				}
			}
			cout << endl;
		}
	}
	~Graph()
	{
		/*for (int i = 0; i < vetixes; i++)
		{
			delete[] vetrix_Graph[];
		}
		delete vetrix_Graph;*/
	}

private:
	bool** vetrix_Graph;
	int vetixes;
};

//int main()
//{
//	Graph<int> g(5);
//
//	g.addEdge(0, 1);
//	g.addEdge(0, 2);
//	g.addEdge(2, 1);
//	g.addEdge(4, 1);
//
//	g.print();
//}
