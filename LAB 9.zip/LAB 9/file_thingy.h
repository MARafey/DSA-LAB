#pragma once
#include<fstream>
using namespace std;

template <typename T>
struct node
{
	T val;
	node<T>* next;

	node(T d)
	{
		this->val = d;
		next = nullptr;
	}

};
template <typename T>
class STACK
{

public:
	node<T>* top;
	node<T>* rear;
	int count;
	STACK()
	{
		top = nullptr;
		rear = nullptr;
		count = 0;

	}
	bool isEmpty()
	{

		if (rear == NULL && top == NULL)
		{
			//cout << "Is Empty" << endl;
			return true;
		}
		else
		{
			return false;
		}
	}
	void push(T d)
	{
		node<T>* p = new node<T>(d);
		p->next = top;
		top = p;
		count++;
	}
	void pop()
	{
		if (isEmpty())
		{
			return;
		}
		else if (top != NULL)
		{
			node<T>* temp = top;
			top = top->next;
			delete temp;

		}
		count--;
	}


	node<T>* Peek()
	{
		return top;
	}
	int sizeofstack()
	{
		return count;
	}
};


bool validate(string a)
{
	STACK<char> st;
	ifstream inFile;

	inFile.open("D:/"+a);
     char c;
	int b = 0;
	int d = 0;
	cout << endl;
	cout << endl;
     if (inFile.is_open()) {
          while (inFile.good()) {
               inFile.get(c);
               if (c == '{' || c == '(' || c == '[')
               {
				st.push(c);
				b++;
               }
			else if (c == '}' || c == ')' || c == ']')
			{
				st.pop();
			}
			if (inFile.eof())
			{
				break;
			}
			cout << c;
          }
     }
	cout << endl;
	cout << endl;
	if (st.isEmpty())
	{
		return true;
	}
	else
	{
		return false;
	}
}