template <typename T>
struct node
{

	T val;
	node<T>* next;

	node(T d)
	{
		this->val = d;
		next = nullptr;
	}



};
template <typename T>
class stack
{

public:
	node<T>* top;
	node<T>* rear;
	int count;
	stack()
	{
		top = nullptr;
		rear = nullptr;
		count = 0;

	}
	bool isEmpty()
	{

		if (rear == NULL && top == NULL)
		{
			cout << "Is Empty" << endl;
			return true;
		}
		else
		{
			return false;
		}
	}
	void push(T d)
	{
		node<T>* p = new node<T>(d);
		p->next = top;
		top = p;
		count++;
	}
	void pop()
	{
		if (isEmpty())
		{
			return;
		}
		else if (top != NULL)
		{
			node<T>* temp = top;
			top = top->next;
			delete temp;

		}
		count--;
	}


	node<T>* Peek()
	{
		return top;
	}
	int sizeofstack()
	{
		return count;
	}
};
template <typename T>
class MinStack
{
public:
	stack<T> s;
	stack<T> aux;

	void push(T val)
	{
		if (aux.isEmpty() && s.isEmpty() )
		{
			aux.push(val);
			s.push(val);
		}
		else
		{
			if (aux.Peek()->val >= val)
			{
				//aux.pop();
				aux.push(val);
			}
			s.push(val);
			
		}
	}
	void pop() //pops elements of both stacks
	{
		s.top = s.top->next;
		aux.top = aux.top->next;
	
	}
	int top() //returns top of main stack
	{
		return s.Peek()->val;
	}
	int size() // returns size of main stack
	{
		return s.sizeofstack();
	}
	bool isEmpty() //returns true/false if main stack is empty
	{
		if (s.top == 0)
		{
			return 1;
		}
	}
	int getMin() //returns top of aux stack
	{
		return aux.Peek()->val;
	}
};